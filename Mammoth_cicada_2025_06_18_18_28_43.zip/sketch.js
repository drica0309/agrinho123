let baloes = [];
let caminho = [];

function setup() {
  createCanvas(600, 400);
  
  // Criar alguns balões para animar
  for (let i = 0; i < 5; i++) {
    baloes.push(new Balao(random(50, 200), height - 50));
  }
}

function draw() {
  background(255);
  
  // Desenhando o campo
  drawCampo();
  
  // Desenhando a cidade
  drawCidade();
  
  // Desenhando e movendo os balões
  for (let balao of baloes) {
    balao.update();
    balao.display();
  }
  
  // Adicionar animação de celebração no final
  if (frameCount % 120 === 0) {
    showFogos();
  }
}

function drawCampo() {
  fill(100, 200, 100);
  rect(0, height / 2, width / 2, height / 2);
  fill(34, 139, 34);
  ellipse(100, height - 80, 100, 100); // Árvore simples
  fill(255, 255, 0);
  ellipse(150, 80, 20, 20); // Sol simples
}

function drawCidade() {
  fill(150, 150, 150);
  rect(width / 2, 0, width / 2, height); // Prédios
  fill(255, 204, 0);
  rect(width - 50, 100, 40, 100); // Janela iluminada
  fill(255);
  ellipse(width - 100, height - 50, 100, 100); // Lua
}

function showFogos() {
  let cor = color(random(255), random(255), random(255));
  for (let i = 0; i < 10; i++) {
    let x = random(width / 2 + 50, width - 50);
    let y = random(50, 150);
    fill(cor);
    noStroke();
    ellipse(x, y, random(30, 50), random(30, 50));
  }
}

// Classe para o balão
class Balao {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.diametro = 30;
    this.cor = color(random(255), random(255), random(255));
  }
  
  update() {
    this.y -= 1; // O balão sobe
    this.x += 0.5; // O balão vai da esquerda para a direita
    if (this.x > width) {
      this.x = width / 2; // Resetando a posição para a próxima vez
      this.y = height - 50;
    }
  }
  
  display() {
    fill(this.cor);
    ellipse(this.x, this.y, this.diametro, this.diametro);
  }
}

